﻿var questions =
    [
        {
            "question": "CSS Stands for?",
            "option1": "Cascading Style Sheets",
            "option2": "Cascading System Sheets",
            "option3": "Cascaded Style Sheets",
            "option4": "None of these",
            "answer":1


        },
        {
            "question": "CLR stands for?",
            "option1": "Common Language Reader",
            "option2": "Common Language Runtime",
            "option3": "Command Language Runtime",
            "option4": "None of these",
            "answer": 2
        },
        {
            "question": "We can handle error at",
            "option1": "Method level",
            "option2": "Page level",
            "option3": "Application level",
            "option4": "All of these",
            "answer": 4
        },
        {
            "question": "The Capital of South Africa is:",
            "option1": "Cape Town",
            "option2": "Dunedin",
            "option3": "Tasmania",
            "option4": "None of these",
            "answer": 1


        },
        {
            "question": "The capital of Spain is:",
            "option1": "Barcelona",
            "option2": "Madrid",
            "option3": "Seville",
            "option4": "None of these",
            "answer": 2
        },
        {
            "question": "Demonetisation took place on which date:",
            "option1": "8th November 2014",
            "option2": "8th December 2016",
            "option3": "6th June 2018",
            "option4": "8th November 2016",
            "answer": 4
        },
        {
            "question": "What are three primary kinds of parameters?",
            "option1": "Input,Integer,String",
            "option2": "Input,String,DateTime",
            "option3": "int,varchar,nvarchar",
            "option4": "Input,Output,InputOutput",
            "answer": 4


        },
        {
            "question": "In which Event you can set the value of a Theme?",
            "option1": "Page_Load",
            "option2": "Page_PreInit",
            "option3": "Page_Render",
            "option4": "None of these",
            "answer": 2
        },
        {
            "question": "Which of the following runs on Client Side?",
            "option1": "ViewState",
            "option2": "HiddenField",
            "option3": "ControlState",
            "option4": "All of these",
            "answer": 4
        },
        {
            "question": "Which of the following runs on Client Side?",
            "option1": "ViewState",
            "option2": "HiddenField",
            "option3": "Application and Session",
            "option4": "All of these",
            "answer": 3
        },


    ];